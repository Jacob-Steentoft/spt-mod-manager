# List of color codes used

- `black` = Junk Keys (normal weapons in vanilla)
- `blue` = Customs, Ground Zero (weapon mods in vanilla)
- `yellow` = Marked Keys (same in vanilla)
- `green` = Factory, Streets of Tarkov
- `red` = Lighthouse
- `violet` = Reserve (almost all reserve keys in vanilla)
- `orange` = Shoreline (quest items in vanilla)
- `tracerYellow` = Bright Yellow/Golden
- `tracerGreen` = Woods (green in green, I see what you did there SirTyler!)
- `tracerRed` = Interchange
- `default` = White Background, common for a lot of items in vanilla (barter, gear, etc.)

Might work with Color Coverter API for more colors, but I have not tested it myself yet.
